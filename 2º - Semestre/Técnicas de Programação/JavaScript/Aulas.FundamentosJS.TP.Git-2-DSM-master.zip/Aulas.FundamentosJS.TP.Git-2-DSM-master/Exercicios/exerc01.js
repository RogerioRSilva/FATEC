/*01) Crie uma função que dado dois valores (passados como parâmetros) mostre no console a soma,
subtração, multiplicação e divisão desses valores.*/

function calcularOperacoes(operador1, operador2){
    console.log(`Soma = ${operador1 + operador2}, Subtração = ${operador1 - operador2}, Multiplicação = ${operador1 * operador2}, Divisão = ${operador1 / operador2}`)
}
calcularOperacoes(2,1)