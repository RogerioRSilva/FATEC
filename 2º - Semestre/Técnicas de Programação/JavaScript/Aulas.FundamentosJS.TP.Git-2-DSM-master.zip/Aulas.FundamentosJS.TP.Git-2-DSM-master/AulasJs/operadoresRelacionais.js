console.log('Teste 1:', '1' == 1)
console.log('Teste 2:', '1' === 1)
console.log('Teste 3:', '2' != 2)
console.log('Teste 4:', '2' !== 2)

console.log('Teste 5:', 3 < 1)
console.log('Teste 6:', 3 > 1)
console.log('Teste 7:', 3 <= 1)
console.log('Teste 8:', 3 >= 3)

const data1 = '10/03/2022'
const data2 = '05/10/2022'
const data3 = '10/03/2022'

console.log('Teste 9:', data1 == data2)
console.log('Teste 9:', data1 == data3)
console.log('Teste 9:', data2 > data3)