// var numero = 1

// { //bloco não é função
//     var numero = 2 // imprimi esse último valor
//     console.log('dentro do bloco =', numero)
// }
// console.log("fora do bloco =", numero)

let num = 1

{ //bloco não é função
    let num = 2 // imprimi esse último valor
    console.log('dentro do bloco =', num)
}
console.log("fora do bloco =", num)


