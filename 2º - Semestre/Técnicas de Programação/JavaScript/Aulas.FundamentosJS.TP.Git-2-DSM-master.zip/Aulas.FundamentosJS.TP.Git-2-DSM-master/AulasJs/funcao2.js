const imprimirSoma = function (a, b){
    console.log(a+b)
}
imprimirSoma(2,3)

const soma = (a,b) => {  //ARROW FUNCTION
   return a + b
}
console.log(soma(5,7))

const sub = (a,b) => a - b
console.log(sub(10,2))

const imp = a => console.log(a)
imp("Olha o tanto que é prático!!!")