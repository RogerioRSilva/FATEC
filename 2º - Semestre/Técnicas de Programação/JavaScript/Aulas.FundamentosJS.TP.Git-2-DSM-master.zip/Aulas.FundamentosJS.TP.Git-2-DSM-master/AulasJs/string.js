const facul = "alexandre"

// document.getElementById('root').innerHTML = facul.charAt(3)
// document.getElementById('root').innerHTML = facul.charCodeAt(1)
// document.getElementById("root").innerHTML = facul.indexOf('B')
// document.getElementById("root").innerHTML = facul.substring(1)
// document.getElementById("root").innerHTML = facul.substring(2, 4)
// document.getElementById("root").innerHTML = "Franca ".concat(facul).concat(" !")
// document.getElementById("root").innerHTML = "Franca ".concat(facul.substring(0,3)).concat(" ! ").concat(facul.substring(3))
// document.getElementById("root").innerHTML = facul.replace(facul.charAt(2), "T")
// document.getElementById("root").innerHTML = facul.substring(0,2).concat("T").concat(facul.substring(3))
// document.getElementById("root").innerHTML = "Alexandre, João, Maria, Pedro".split(", ")
console.log(facul.split(""))