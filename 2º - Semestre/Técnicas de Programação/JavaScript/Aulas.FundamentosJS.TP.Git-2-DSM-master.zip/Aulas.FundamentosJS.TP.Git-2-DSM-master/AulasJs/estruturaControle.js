function resutado(nota){
    if(nota >= 6){
        console.log("Aprovado com nota ", nota)
    }else{
        console.log("Reprovado com nota "+ nota)
    }
}
resutado(5)