var x = "Ola pessoal!!!"

document.getElementById("root").innerHTML = x;