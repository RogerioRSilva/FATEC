// const notas = [6.7, 7.5, 8.2, 9.3, 10]

// for(let i in notas){
//     console.log(i, notas[i])
// }

const pessoa = {
    nome: "Alexandre",
    sobrenome: "Gomes",
    idade: "25",
    peso: "70"
}

for(let i in pessoa){
    console.log(`${i} = ${pessoa[i]}`)
}