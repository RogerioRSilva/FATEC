const produto1 = {}

produto1.nome = 'tenis1'
produto1.marca = 'nike1'
produto1.original = true
produto1.preco = 501

console.log(produto1)

const produto2 = {
    nome: 'tenis2',
    marca: 'nike2',
    original: true,
    preco: 502
}
console.log(produto1.nome)
console.log(produto2.nome)

